-- italian_fts -- uninstall script
--
-- Copyright (C) 2007-2011 Daniele Varrazzo


DROP TEXT SEARCH CONFIGURATION italian_ispell;
DROP TEXT SEARCH DICTIONARY italian_ispell;
